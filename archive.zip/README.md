# RUXUP Client
## How to use this project
clone this repo and run npm to get all needed dependencies:

```bash
$ npm install
```


Everything is set up to serve from the www folder using
```bash
$ npm serve
```

## DEMO
[Ruxup App](http://ruxup-client.herokuapp.com)